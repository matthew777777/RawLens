// SPDX-License-Identifier: Apache-2.0
#pragma once
// LK-R Lite copy of LK-R's solver API (lkr-pipeline lkr_solver.h, 2026-11-13): same SolveParams /
// SolveStats / Solver::solve signature so the copied MergeFull (lkrl_full) drives Lite unchanged.

// LK-Reloaded solver for one tile (Lecouat, Ponce, Mairal, ICCV 2021):
// HQS with one Gauss-Newton (Lucas-Kanade) motion step per iteration and a
// plug-and-play prior. Same math and conventions as python/lkr/lkr_torch.py
// (the parity reference); see shaders/lkr_common.glsl.

#include <cstdint>
#include <array>
#include <functional>
#include <string>
#include <deque>
#include <memory>
#include <vector>

#include "lkrl_gpu.h"
#include "lkrl_solver.h"

namespace lkrl {

// Plug-and-play prior x = f(z, sigma). z and x are 3 planes of H*W floats
// (camera-linear, RGGB order R,G,B); they point straight into the mapped
// GPU buffers (no copies on unified memory). Returns false on failure.
// noise_scale: per-HR-pixel factor (H*W, >= 1) on the noise level, from the
// fraction of frames that contributed there (robust weights); null = 1.
using PriorFn = std::function<bool(const float* z, float* x, int H, int W, float sigma, const float* noise_scale)>;

struct SolveParams {
  int s = 2;
  int T = 16;
  int z_steps = 3;
  float sigma_noise = 0.01f;   // data-term scale (our own estimate)
  float sigma_max = 0.1f;      // schedule start
  float sigma_end = 0.01f;     // schedule end
  float lam = 1.0f;
  float step_scale = 1.8f;     // eta = c/(L+mu); c < 2 is stable with the L bound
  bool refine_motion = true;
  std::vector<int> prior_at;   // empty = every iteration
  // Non-learned x-step on the prior iterations (shaders/dct_x.comp). H and W must be multiples of 4.
  bool dct_prior = false;
  // Without dct_prior: one DCT pass at the end, only on tiles that lost frames and only for the
  // excess colour noise. Luma is unchanged unless dct_prior is explicitly on.
  bool dct_fallback = true;    // Lite: light DCT cleanup only where frames were lost (2026-11-14; --fallback 0 = off)
  // Opt-in pixel-aperture frequency shaping; zero preserves existing DCT thresholds.
  float dct_aperture = 0.0f;
  const float* model_error = nullptr;  // optional H*W nonnegative variance map, tile HR coordinates
  bool band_rejection = false;  // experimental same-CFA, cycle-spun Haar confidence; requires model_error
  float band_k = 1.0f;          // high-band noise standard deviations (1 = noise-calibrated)
  // dct_prior on: noise-following luma, shadows keep at most dct_grain x mid-grey's relative grain
  // (1 = as grainy as mid-grey), luma strength dct_luma. Chroma (always): dct_chroma x total noise.
  float dct_grain = 1.0f;
  float dct_luma_floor = 0.10f;
  float dct_luma_cap = 0.25f;     // dct_prior on: at most this share removed (deepest shadows keep grain)   // dct_prior on: at least this share of luma noise variance removed (mid-tones / highlights)
  // Night look (2026-11-20): luma keeps grain of std dct_grain_rel x local luma (film / DSLR-like, gain
  // invariant), at least dct_grain_rho of the noise variance; 0 = off. Self-gating: blocks cleaner than the
  // kept grain are not touched. dct_chroma_norm: colour thresholds in colour-noise units (see dct_x.glsl).
  // Defaults (user 2026-11-20, night burst IMG_20260921_194618_520: "almost no chroma, no bleeding,
  // organic DSLR / film luma"): 8 % relative grain, at least 20 % of the noise variance kept, coarse
  // frequencies shrunk harder (tilt 0.7). Day burst 184641: no pixel changes by more than 0.01.
  float dct_grain_rel = 0.08f, dct_grain_rho = 0.2f, dct_grain_tilt = 0.7f;
  float dct_grain_sub = 0.0f;   // grain mode: > 0 = detail-keeping subtraction gain (beta), 0 = Wiener-type rule
  bool dct_chroma_norm = true;
  float dct_luma = 2.0f, dct_chroma = 2.0f;   // noise-sigma multipliers; 16 erased real leaf colour
  // Dark blocks (mean luma below dct_dark_level, full effect below a quarter) use their measured
  // AC energy as the noise level when it exceeds the model, up to dct_dark_cap x (1 = off).
  float dct_dark_level = 0.02f, dct_dark_cap = 8.0f;
  float dct_dark_luma = 0.25f;   // share of the dark boost applied to luma (colour always gets all of it)
  float L = 0.0f;              // >0 given; 0 = Schur bound max(U^T 1); <0 = power iteration
  // Look controls (not in the paper; PSNR-tuned values give a waxy look):
  float prior_gain = 0.4f;     // sigma handed to the prior = gain * sigma_t (0.4: DSLR look, user-picked)
  // Robust data term (moving objects / occlusion): Cauchy IRLS weights against
  // our noise model sigma^2 = noise_a y + noise_b, from iteration robust_start.
  bool robust = true;
  // Reference-only sqrt RGB guide confidence (shaders/guide_stats, weight_guide) replaces
  // the running-HR residual confidence, which rejected aliased static detail the HR
  // estimate had not learned yet; temporal protection and spread remain. 0 = off
  // (residual confidence). Validation: docs/performance/lkr-rejection-validation-2026-11-13.md.
  // LK-R Lite (app engine since 2026-11-14): guide ON by default, as the user requires ("guide must stay
  // on"). Guide-off fell back to Lite's simplified residual chain: perforated-panel mesh 74 % of LK-R's
  // finest-band energy (IMG_20210228 1x) vs 84 % / visually equal with the guide. debug.lkr.guide 0 = off.
  float guide_confidence = 2.0f;
  // > 0: a frame must also pass the residual test: w = min(guide, residual^guide_residual).
  float guide_residual = 0.0f;
  // Diagnostic only: known-static rectangle in this tile's reference LR coordinates.
  // No inferred/static mask is enabled in the app. Width/height zero disables it.
  std::array<float, 4> trusted_static{0, 0, 0, 0};
  bool equalize_noise = true;
  // How much the denoiser map / grain follow the contributing-frame factor
  // (0..1; the luma Bayer notch always uses the full factor). MergeFull sets it
  // from the noise level: in clean daylight one reference frame is barely
  // noisy, and full strength smeared static texture where a moving shadow
  // rejected frames (rock bunker under a swaying tree, IMG_20261104_111404).
  float equalize_strength = 1.0f;
  // Temporal weighting: also reject frame k where it disagrees with the
  // REFERENCE-only start image (not the running merge, which already holds
  // the average of e.g. moving water). 0 = off.
  float temporal_k = 3.0f;
  float temporal_tau = 0.6f;
  // Dark-area motion test: in deep shadow a moving dark object differs from a dark background by
  // about the noise of the 5x5 test, so where the local mean signal is below temporal_dark_level
  // (full effect below a quarter of it) a wider 9 x 15 window is tested too, at the same threshold.
  bool temporal_dark_wide = true;
  float temporal_dark_level = 0.02f;
  // Energy test tolerance for single-frame model error, as a fraction of the
  // local detail energy common to the frame and its prediction. 0 = off.
  float temporal_detail = 4.0f;
  int robust_spread = 3;        // min-filter radius (LR px) on the robust weights (Wronski robustness); 0 = off
  // EXPERIMENT (0 = off): where accepted frames disagree beyond their noise, show the average over one
  // Bayer period (smooth motion blur) instead of per-site blocks; see the motion-look comment in solve().
  float motion_smooth = 0.0f;
  // false: flagged pixels become the time average of the frames (single-frame resolution).
  // true: they keep the merge and lose only the part of (merge - time average) locked to the Bayer grid.
  bool motion_smooth_sr = false;
  // Back-projection steps on the upsampled start image so its s x s block means reproduce the
  // demosaiced reference (see the start-image comment in lkr_solver.cpp). 0 = plain bilinear (A/B).
  int init_backproject = 0;   // off until validated; 3 removes the reference-only zipper on the car burst
  bool mhc_init = true;         // start from the encoded-video coherent MHC (lkr_mhc, = MhcReference); false = bilinear (paper)   // prior noise map / grain follow the contributing-frame count
  float robust_k = 3.0f;
  float robust_pow = 1.0f;     // rejection curve steepness (1 = Cauchy, 2 = steep: no half-weight blending of moving foliage)
  float robust_tau = 0.1f;      // edge tolerance (LR px misregistration): 0.3 let moving-car edges ghost, 0 rejects static edges
  int robust_start = 0;        // from the start: late rejection leaves ghost colour at unsampled sites
  float noise_a = 0.0f, noise_b = 0.0f;
  // Local motion (wind, moving objects that can be tracked): per-frame
  // translation per local_block x local_block LR block on top of the tile
  // affine, refined by Gauss-Newton each iteration, regularised towards the
  // neighbouring blocks with weight local_lambda * (trace + local_floor).
  int local_block = 16;         // 0 = off (paper model); 16 = jacblk workgroup size
  float local_lambda = 0.1f;
  float local_floor = 0.02f;
  const float* local_init = nullptr;   // optional K x nb vec2 initial field (block search)
  float* local_out = nullptr;          // optional: final field (diagnostics)
  // Prior must not move the local mean: x += lowpass(z - x) after each
  // prior call (GAT-domain denoising lifts night shadows: R/G 1.10 vs raw
  // truth 0.98). Box radius in HR px, 0 = off.
  int mean_preserve = 8;
  // Shadow cleanup (RawLens look): where the local relative noise
  // sqrt(a L + b) / L is well above its mid-grey value, raise the prior's
  // noise map by up to (1 + shadow_boost) -- the network denoises shadows
  // harder, edge-aware -- and return grain divided by the same factor;
  // shadow_chroma blends shadow chroma toward its local mean. 0 = off.
  // Values are the DAY strengths; MergeFull's auto look fades them to 0 at night.
  // Luma boost default 0 (2026-11-04): raising the prior's noise map in
  // "shadows" painted grass and foliage into brush strokes, and in HDR scenes
  // (sky-exposed, IMG HDR+ 5a9e) the whole foreground counts as shadow. The
  // chroma part below keeps daylight shadow colour noise below Google HDR+.
  float shadow_boost = 0.0f;
  float shadow_chroma = 0.7f;
  // Blown highlights go white: neutralise once any channel nears clip (FinishLook).
  bool highlight_desat = true;
  // Highlight reconstruction (inpaint opposed, darktable / OpposedHighlightsVulkan idea, 2026-11-20): a
  // clipped channel is rebuilt from the UNCLIPPED channels with the colour of the reference's unclipped
  // pixels bordering clipped areas (wb space, G = 1): c = col_c * mean_k(v_k / col_k) over unclipped k.
  // {1, 1, 1} = neutral. Only pixels with ALL channels clipped are then made plain white.
  float hl_ratio[3] = {1.0f, 1.0f, 1.0f};
  // EXPERIMENT (off): where frames were rejected, pull chroma toward its 3x3 median applied twice,
  // scaled by the lost-frame factor -- removes reference-frame false colour on aliased wires/railings.
  float fallback_chroma = 0.0f;
  // Held-out validation (diagnostics): the LAST frame is left out of the merge, aligned to the
  // finished image and compared with it; SolveStats::ho_r / ho_valid receive the result.
  bool holdout = false;
  std::string debug_prefix; // opt-in per-tile trace, unique path owned by MergeFull
  bool debug_maps = false;   // fill SolveStats::dbg (LKR_DEBUG_MAPS)
  bool notch = true;           // remove Bayer-period (zipper/maze) structure from colour + grain
  float clip = 0.98f;          // normalised level at/above which a raw sample is treated as clipped
  // HDR bracket (Lecouat et al. 2022): exposure of each merged frame relative to the reference
  // (frame 0), e.g. 1 1 1 1 1 0.25 0.25 2.83. Samples arrive already divided by it (reference
  // units; clipped samples above `clip`); the merge weights each frame by its own noise
  // variance a y / e + b / e^2. Empty = equal exposures (the default merge, unchanged).
  std::vector<float> exposure;
  float grain = 0.4f;          // add back grain * (removed detail), luminance only (neutral)
  std::array<float, 3> wb{1.0f, 1.0f, 1.0f};   // white balance for the luminance grain
  bool gather = false;
  // Robust data step as a gather (no atomics) instead of the int32-atomic
  // scatter. Exact transpose, same image (61-70 dB), but measured 1.8x SLOWER
  // on Mali-G615 (1024^2: 34.0 s vs 18.6 s): kept as an A/B switch only.
  // One GPU invocation per 2x2 Bayer quad (vec2 row loads, shared affine +
  // local block per quad) for the per-sample robust passes; per-sample maths
  // unchanged (rounding-level diff). Measured NO gain on Mali-G615 (1024^2:
  // 19.5-19.9 s vs 20.2-20.9 s; these passes are bound by the scattered HR
  // tap reads and int atomics, not by the y/wt loads): A/B switch only.
  bool quad = false;
  // Frame-innermost workgroup order per pass (bit 1 resid_adj_w, 2 resid, 4 scatter):
  // a cache-locality choice only, the result is identical either way.
  int frame_inner = 7;
  // jacblk reads jac.comp per-pixel terms: ~1.4 s faster on Mali but NOT bit-identical (rounding of r /
  // Jx / Jy differs between the two shaders; held-out score 4.584 -> 4.596 at 1x). Off until approved.
  bool jac_fuse = false;
  bool weight_skip = true;   // weight.comp skips rw/wv that weight_min overwrites (false: A/B reference)
  bool temporal_det_once = true;   // weight_tdet.comp precompute (false: A/B reference, same result)
  // Packed bilinear taps (malioc: every pass is load/store bound): zpack.comp
  // stores each HR pixel's 2x2 taps as one vec4 so the robust residual /
  // adjoint passes read 1 vector instead of 4 scalars per sample. Same maths
  // (bit-identical). malioc LS cycles drop 20-30%, but measured SLOWER on the
  // phone (adjoint 3.0 -> 4.5 s, residual 1.2 -> 2.5 s per 1024^2): the packed
  // copy is 4x the bytes and misses cache; the 4 scalar taps share lines.
  // These passes are cache/bandwidth bound, not instruction bound. A/B only.
  bool pack_taps = false;
  // EXPERIMENT: the residual / adjoint passes read a half-float copy of z (zhalf.comp): half the
  // bytes per bilinear tap. Rounds z to 11 bits for those reads, so not bit-identical.
  bool half_taps = false;
  // Motion refinement (Eq. 7, global + local) on every iteration for the first
  // motion_warmup iterations, then every motion_every-th (1 = paper: always).
  int motion_every = 2;
  int motion_warmup = 4;
  bool robust_gather = false;         // adjoint as gather fused with the z-step (no atomics); false = scatter (faster on Mali + M1)
  int power_iters = 60;
  float power_tol = 0.0f;      // stop when |dL| <= tol*L (0 = run all)
};

struct SolveStats {
  float L = 0.0f;
  double gpu_ms = 0.0, prior_ms = 0.0, total_ms = 0.0;
  int prior_calls = 0, submits = 0, power_iters_used = 0;
  double init_ms = 0.0, finish_ms = 0.0;   // CPU: buffers + start image; FinishLook
  uint64_t dispatches = 0;
  // Diagnostics (SolveParams::debug_maps): kDebugMaps planes of H x W (HR):
  // effective frames (sum of final weights, reference 1), mean temporal weight
  // of frames 1..K-1, noise-equalisation factor, shadow weight, max local
  // motion |d| (LR px).
  std::vector<float> dbg;
  // SolveParams::holdout: per LR sample of the held-out frame (h x w), prediction minus sample,
  // and 1 where the sample is usable (inside the image, not clipped).
  std::vector<float> ho_r, ho_valid;
};
constexpr int kDebugMaps = 5;

// Two-phase tile solve (solveBegin / solveEnd): the GPU fit is done in Begin and the NPU prior (when
// enabled) is started asynchronously, so the caller can fit its next tile on the GPU before End waits for
// it and runs the finishing on this worker's GPU objects.
struct PendingTile;
struct PendingDeleter { void operator()(PendingTile* p) const; };
using PendingPtr = std::unique_ptr<PendingTile, PendingDeleter>;

class Solver {
 public:
  explicit Solver(Gpu* gpu);
  ~Solver();
  bool ok() const { return ok_; }
  std::string profileNames() const;   // pointer -> shader name map for Gpu::profileReport

  // frames: K x h x w RGGB raw in [0,1] (frame 0 = reference; with prm.holdout the last one is
  // only compared, not merged); p: K x 6 affine motions in/out; x_out: 3 x (s h) x (s w).
  bool solve(const float* frames, int K, int h, int w, float* p, const SolveParams& prm,
             const PriorFn& prior, std::vector<float>* x_out, SolveStats* st);
  bool solveBegin(const float* frames, int K, int h, int w, float* p, const SolveParams& prm,
                  const PriorFn& prior, PendingPtr* pend);
  bool solveEnd(PendingPtr* pend, std::vector<float>* x_out, SolveStats* st);

 private:
  // LK-R Lite: the GPU work is LiteSolver; SolveParams fields it does not use are ignored.
  Gpu* gpu_;
  LiteSolver lite_;
  bool ok_ = false;
};

// CPU helpers (exact mirrors of the python reference).
void FinishLook(const float* z, float* x, int H, int W, const SolveParams& prm, const float* noise_scale = nullptr,
                const float* shadow = nullptr);
void MotionLook(const float* frames, int K, int h, int w, const float* rr, const float* wtb, const float* pm,
                const float* dl, const SolveParams& prm, float* z, float* x);

}  // namespace lkrl
